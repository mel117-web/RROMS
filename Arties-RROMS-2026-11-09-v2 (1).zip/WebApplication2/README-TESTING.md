# Artie's RROMS – how to run and test

## 1. Open the project
1. Unzip this folder anywhere (e.g. `Documents\RROMS`).
2. Double-click **WebApplication2.slnx** to open it in **Visual Studio 2026**.
3. Wait for NuGet packages to restore (bottom-left status bar), then **Build > Build Solution** (Ctrl+Shift+B).

## 2. Database
Just press **F5**. The app creates/updates the local database **RROMS** on `(localdb)\mssqllocaldb`
automatically at startup (all migrations, including AddPromotionDetails, are in the Migrations folder)
and fills it with the sample restaurant, tables, menu and test accounts.

If it ever complains, open **Tools > NuGet Package Manager > Package Manager Console** and run `Update-Database`.

## 3. Test accounts
| Role     | Email                | Password     | Where to log in |
|----------|----------------------|--------------|-----------------|
| Admin    | admin@rroms.com      | Admin@123    | `https://localhost:7291/Identity/Account/StaffLogin` |
| Staff    | staff@rroms.com      | Staff@123    | `https://localhost:7291/Identity/Account/StaffLogin` |
| Customer | customer@rroms.com   | Customer@123 | Normal login page (or register a new one) |

There is no "Staff / Admin login" button on purpose: staff and admin use the StaffLogin link directly.
Opening an /AdminPanel or /StaffPanel page while logged out also takes you there.

Google / Facebook / Microsoft buttons only appear on a PC that has the login keys in User Secrets.
On your PC you'll just see email + password, which is expected.

## 4. What to test
**Customer**
- Register, log in, edit profile and password
- Book a table, modify it, cancel it (My Reservations)
- Browse the menu, add to cart, checkout
- Promo code at checkout (create one in Admin > Promos first)
- Pay Online (demo gateway, no real money) or Pay at Counter; "Pay Online" button in My Orders for unpaid orders
- My Orders: status tracker updates while staff move the order
- My Reviews: rate a completed visit
- Tony (chat bubble, bottom right): ask about hours, menu, prices, your order, promotions

**Staff**
- Today's Reservations: confirm, seat, complete, no-show, cancel, modify
  (seat/complete/no-show only work on the day of the booking)
- Active Orders: Pending > Preparing > Ready > Served (orders already paid online complete automatically)
- Billing: view bill, adjust with a reason, settle with Cash or E-Wallet, print receipt
- Feedback: recent reviews

**Admin**
- Dashboard numbers and charts
- Restaurant (areas with photo upload, tables, hours) and Menu (categories, items with photo upload, availability)
- Users: add a staff account, suspend/activate, delete
- Promos: promotions (percent or fixed, whole order / category / promo code) and announcements
- Orders, Reviews (reply), Reports (each type and date range, Export to CSV)

## 5. Reporting bugs
For each problem, send: the page URL, what you clicked, what you expected, and a screenshot of the error.
